﻿using System;

namespace Taste.Utility
{
    public class Class1
    {
    }
}
