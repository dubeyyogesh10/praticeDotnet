﻿using System;

namespace Taste.Models
{
    public class Class1
    {
    }
}
